# Companion 0.3.13 — Midir 49.a import fixtures

Extract this delivery pack first, then import each inner ZIP individually. All current reports are fictional synthetic test data generated through the actual Midir exporter, not live recordings. Read COMPANION-HANDOFF.md and SESSION-BUNDLE-SPEC.md for the contract. Preserve original HTML for embedded viewing.

| Fixture | Expected result |
|---|---|
| single.zip | A, one recording, HTML; identical to individual.html |
| standard.zip | A, B, C; three unique recording IDs and original HTML reports, DEFLATE |
| store.zip | Same exact entries as standard.zip, STORE; importing both adds no duplicates |
| overlap-a.zip | A, B |
| overlap-b.zip | B, C; after overlap-a, three unique recordings, one duplicate |
| one-player.zip | A narrower player scope, not a new recording |
| large.zip | 128 reports, including 6,000 exact hits in one |
| legacy.zip | One pre-manifest style HTML; no durable export metadata |
| retired-49-json.zip | Historical 49 data-only format; optional support or clear rejection; no original HTML |
| individual.html | A, exact HTML bytes from single.zip |
| legacy-id-input.ndjson | Identity algorithm vector, not a ZIP import or replay of report C |

IDs A/B are permanent-style fixture IDs; C is legacy-sha256. All reports include original embedded JSON and viewer except the explicitly retired JSON archive. All current sample ZIPs use either standard ZIP DEFLATE or STORE, not encryption, ZIP64, or external resources. Test standalone and embedded report viewing separately. See SESSION-BUNDLE-VERIFICATION.md for actual producer results and limitations.
